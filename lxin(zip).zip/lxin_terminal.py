#!/usr/bin/env python3
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import subprocess, os, tempfile, threading, time, shutil

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

SUGGESTIONS = [
    "say: \"Hello world!\"",
    "luse [python]: \"print('Hello from Python')\"",
    "luse [csharp]: \"Console.WriteLine(\\\"Hello from C#\\\");\"",
    "<<CSHARP",
    "CSHARP",
    "luse [python]: \""\"",
    "import requests",
    "http.get \"https://example.com\" -> result"
]

class LXinTerminal(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LXin Code Terminal")
        self.geometry("1000x700")
        menubar = tk.Menu(self)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="New", command=self.new_file)
        filemenu.add_command(label="Open...", command=self.open_file)
        filemenu.add_command(label="Save", command=self.save_file)
        filemenu.add_command(label="Download .lx", command=self.download_file)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=filemenu)
        runmenu = tk.Menu(menubar, tearoff=0)
        runmenu.add_command(label="Run", command=self.run_code)
        runmenu.add_command(label="Debug (capture errors)", command=self.debug_code)
        runmenu.add_command(label="Auto-guess typing", command=self.auto_guess_typing)
        menubar.add_cascade(label="Run", menu=runmenu)
        self.config(menu=menubar)
        self.editor = scrolledtext.ScrolledText(self, wrap=tk.NONE, font=("Consolas", 12))
        self.editor.pack(fill=tk.BOTH, expand=True)
        self.output = scrolledtext.ScrolledText(self, height=10, wrap=tk.WORD, font=("Consolas", 11), bg="#111", fg="#ddd")
        self.output.pack(fill=tk.X)
        frame = tk.Frame(self)
        frame.pack(fill=tk.X)
        tk.Button(frame, text="Run", command=self.run_code).pack(side=tk.LEFT, padx=4, pady=4)
        tk.Button(frame, text="Debug", command=self.debug_code).pack(side=tk.LEFT, padx=4, pady=4)
        tk.Button(frame, text="Auto-guess", command=self.auto_guess_typing).pack(side=tk.LEFT, padx=4, pady=4)
        tk.Button(frame, text="Download .lx", command=self.download_file).pack(side=tk.RIGHT, padx=4, pady=4)
        tk.Button(frame, text="Load demo TicTacToe", command=self.load_demo).pack(side=tk.RIGHT, padx=4, pady=4)
        self.status = tk.Label(self, text="Ready", anchor="w")
        self.status.pack(fill=tk.X)
        self.new_file()

    def new_file(self):
        demo = "# New LXin file. Use luse [python]: \"...\" or <<CSHARP ... CSHARP blocks.\n"
        self.editor.delete("1.0", tk.END)
        self.editor.insert("1.0", demo)
        self.status['text'] = "New file"

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("LXin files","*.lx"),("All files","*.*")])
        if not path: return
        with open(path, "r", encoding="utf-8") as f:
            self.editor.delete("1.0", tk.END)
            self.editor.insert("1.0", f.read())
        self.status['text'] = f"Opened: {os.path.basename(path)}"

    def save_file(self):
        path = filedialog.asksaveasfilename(defaultextension=".lx", filetypes=[("LXin files","*.lx")])
        if not path: return
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.editor.get("1.0", tk.END))
        self.status['text'] = f"Saved: {os.path.basename(path)}"
        messagebox.showinfo("Saved", "File saved successfully.")

    def download_file(self):
        path = filedialog.asksaveasfilename(initialfile="script.lx", defaultextension=".lx", filetypes=[("LXin files","*.lx")])
        if not path: return
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.editor.get("1.0", tk.END))
        self.status['text'] = f"Downloaded: {os.path.basename(path)}"
        messagebox.showinfo("Downloaded", f"Downloaded LX file to: {path}")

    def run_code(self):
        code = self.editor.get("1.0", tk.END)
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".lx", encoding="utf-8") as tf:
            tf.write(code)
            tfname = tf.name
        self.status['text'] = f"Running {os.path.basename(tfname)}..."
        self.output.delete("1.0", tk.END)
        def target():
            py = shutil.which("python") or shutil.which("python3")
            if not py:
                self.output.insert(tk.END, "Python not found on PATH. Install Python.\n")
                self.status['text'] = "Error: Python missing"
                return
            proc = subprocess.Popen([py, os.path.join(BASE_DIR, "lxin_core.py"), tfname], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            out, err = proc.communicate()
            if out:
                self.output.insert(tk.END, out + "\n")
            if err:
                self.output.insert(tk.END, "ERROR:\n" + err + "\n")
            self.status['text'] = "Run finished"
        threading.Thread(target=target, daemon=True).start()

    def debug_code(self):
        code = self.editor.get("1.0", tk.END)
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".lx", encoding="utf-8") as tf:
            tf.write(code)
            tfname = tf.name
        self.status['text'] = f"Debugging {os.path.basename(tfname)}..."
        self.output.delete("1.0", tk.END)
        py = shutil.which("python") or shutil.which("python3")
        if not py:
            self.output.insert(tk.END, "Python not found on PATH. Install Python.\n")
            self.status['text'] = "Error: Python missing"
            return
        proc = subprocess.Popen([py, os.path.join(BASE_DIR, "lxin_core.py"), tfname], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = proc.communicate()
        if out:
            self.output.insert(tk.END, out + "\n")
        if err:
            self.output.insert(tk.END, "DEBUG ERRORS:\n" + err + "\n")
            lines = code.splitlines()
            context = "\n".join(lines[max(0, len(lines)-10):])
            self.output.insert(tk.END, "\nCode context (last 10 lines):\n" + context + "\n")
        self.status['text'] = "Debug finished"

    def auto_guess_typing(self):
        suggestion = SUGGESTIONS[int(time.time()) % len(SUGGESTIONS)]
        idx = self.editor.index(tk.INSERT)
        def typer():
            for ch in suggestion:
                self.editor.insert(idx, ch)
                time.sleep(0.02)
            self.status['text'] = "Auto-guess inserted suggestion"
        threading.Thread(target=typer, daemon=True).start()

    def load_demo(self):
        demo_path = os.path.join(BASE_DIR, "demo_tictactoe.lx")
        if os.path.exists(demo_path):
            with open(demo_path, "r", encoding="utf-8") as f:
                self.editor.delete("1.0", tk.END)
                self.editor.insert("1.0", f.read())
            self.status['text'] = "Loaded demo_tictactoe.lx"
        else:
            messagebox.showerror("Missing file", "demo_tictactoe.lx not found in application folder.")

if __name__ == '__main__':
    app = LXinTerminal()
    app.mainloop()
