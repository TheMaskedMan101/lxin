import sys
print("Running LXin placeholder on", sys.argv[1])
with open(sys.argv[1]) as f:
    print(f.read())
